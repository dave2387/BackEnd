import React from 'react'

function page() {
  return (
    <h1>
        Dashboard page
    </h1>
  )
}

export default page
